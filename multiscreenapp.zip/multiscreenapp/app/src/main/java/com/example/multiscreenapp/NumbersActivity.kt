package com.example.multiscreenapp

import android.os.Bundle
import android.speech.tts.TextToSpeech
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity
import java.util.*

class NumbersActivity : AppCompatActivity(), TextToSpeech.OnInitListener {

    private lateinit var tts: TextToSpeech

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_numbers)

        tts = TextToSpeech(this, this)

        val buttonIds = listOf(
            R.id.btnOne to "One",
            R.id.btnTwo to "Two",
            R.id.btnThree to "Three",
            R.id.btnFour to "Four",
            R.id.btnFive to "Five",
            R.id.btnSix to "Six",
            R.id.btnSeven to "Seven",
            R.id.btnEight to "Eight",
            R.id.btnNine to "Nine",
            R.id.btnTen to "Ten",
            R.id.btnEleven to "Eleven",
            R.id.btnTwelve to "Twelve",
            R.id.btnThirteen to "Thirteen",
            R.id.btnFourteen to "Fourteen",
            R.id.btnFifteen to "Fifteen",
            R.id.btnSixteen to "Sixteen",
            R.id.btnSeventeen to "Seventeen",
            R.id.btnEighteen to "Eighteen",
            R.id.btnNineteen to "Nineteen",
            R.id.btnTwenty to "Twenty"
        )

        buttonIds.forEach { (id, word) ->
            findViewById<Button>(id).setOnClickListener {
                speak(word)
            }
        }
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            tts.language = Locale.UK
        }
    }

    private fun speak(text: String) {
        tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "")
    }

    override fun onDestroy() {
        if (::tts.isInitialized) {
            tts.stop()
            tts.shutdown()
        }
        super.onDestroy()
    }
}
