package com.example.multiscreenapp

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val numbersButton = findViewById<Button>(R.id.numbersButton)
        val fruitsButton = findViewById<Button>(R.id.fruitsButton)

        numbersButton.setOnClickListener {
            startActivity(Intent(this, NumbersActivity::class.java))
        }

        fruitsButton.setOnClickListener {
            startActivity(Intent(this, FruitsActivity::class.java))
        }
    }
}
