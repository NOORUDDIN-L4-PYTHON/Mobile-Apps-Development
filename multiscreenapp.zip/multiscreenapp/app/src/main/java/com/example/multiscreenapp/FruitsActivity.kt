package com.example.multiscreenapp

import android.os.Bundle
import android.speech.tts.TextToSpeech
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity
import java.util.*

class FruitsActivity : AppCompatActivity(), TextToSpeech.OnInitListener {

    private lateinit var tts: TextToSpeech

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_fruits)

        tts = TextToSpeech(this, this)

        val buttonIds = listOf(
            R.id.btnApple to "Apple",
            R.id.btnBanana to "Banana",
            R.id.btnCherry to "Cherry",
            R.id.btnOrange to "Orange",
            R.id.btnGrape to "Grape",
            R.id.btnMango to "Mango",
            R.id.btnWatermelon to "Watermelon",
            R.id.btnPineapple to "Pineapple",
            R.id.btnStrawberry to "Strawberry",
            R.id.btnPeach to "Peach",
            R.id.btnKiwi to "Kiwi",
            R.id.btnLemon to "Lemon",
            R.id.btnAvocado to "Avocado",
            R.id.btnBlueberry to "Blueberry",
            R.id.btnCoconut to "Coconut",
            R.id.btnMelon to "Melon"
        )

        buttonIds.forEach { (id, word) ->
            findViewById<Button>(id).setOnClickListener {
                speak(word)
            }
        }
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            tts.language = Locale.UK
        }
    }

    private fun speak(text: String) {
        tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "")
    }

    override fun onDestroy() {
        if (::tts.isInitialized) {
            tts.stop()
            tts.shutdown()
        }
        super.onDestroy()
    }
}
